// Display event details in a modal
function showEventDetails(details) {
    const modal = document.getElementById("event-modal");
    const eventDetails = document.getElementById("event-details");
    eventDetails.textContent = details;
    modal.style.display = "flex";
}

// Close the modal
function closeModal() {
    const modal = document.getElementById("event-modal");
    modal.style.display = "none";
}

// Close modal if clicked outside of content
window.onclick = function(event) {
    const modal = document.getElementById("event-modal");
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
